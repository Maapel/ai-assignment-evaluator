#!/usr/bin/env python3
"""
Keyboard Layout Optimization via Simulated Annealing


Notes:
- Cost is total Euclidean distance between consecutive characters.
- Coordinates are fixed (QWERTY-staggered grid). Optimization swaps assignments.

This base code uses Python "types" - these are optional, but very helpful
for debugging and to help with editing.

"""

import argparse
import json
import math
import os
import random
import string
import time
from dataclasses import dataclass
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt  # type: ignore


Point = Tuple[float, float]
Layout = Dict[str, Point]


def qwerty_coordinates(chars: str) -> Layout:
    """Return QWERTY grid coordinates for the provided character set.

    The grid is a simple staggered layout (units are arbitrary):
    - Row 0: qwertyuiop at y=0, x in [0..9]
    - Row 1: asdfghjkl at y=1, x in [0.5..8.5]
    - Row 2: zxcvbnm at y=2, x in [1..6]
    - Space at (4.5, 3)
    Characters not present in the grid default to the space position.
    """
    row0 = "qwertyuiop"
    row1 = "asdfghjkl"
    row2 = "zxcvbnm"

    coords: Layout = {}
    for i, c in enumerate(row0):
        coords[c] = (float(i), 0.0)
    for i, c in enumerate(row1):
        coords[c] = (0.5 + float(i), 1.0)
    for i, c in enumerate(row2):
        coords[c] = (1.0 + float(i), 2.0)
    coords[" "] = (4.5, 3.0)

    # Backfill for requested chars; unknowns get space position.
    space_xy = coords[" "]
    for ch in chars:
        if ch not in coords:
            coords[ch] = space_xy
    return coords


def initial_layout(chars: str) -> Layout:
    """Create an initial layout mapping chars to the QWERTY coordinate grid."""
    # Get the fixed coordinate positions from the QWERTY layout.
    coords = qwerty_coordinates(chars)
    # Map each character to its default QWERTY position.
    layout = {ch: coords.get(ch, coords[" "]) for ch in chars}
    return layout


def preprocess_text(text: str, chars: str) -> str:
    """Lowercase and filter to the allowed character set; map others to space."""
    allowed_chars = set(chars)
    # Use a generator expression for efficiency
    return "".join(c if c in allowed_chars else " " for c in text.lower())


def path_length_cost(text: str, layout: Layout) -> float:
    """Sum Euclidean distances across consecutive characters in text."""
    total_distance = 0.0
    for i in range(len(text) - 1):
        char1, char2 = text[i], text[i+1]
        
        # Skip distance calculation if characters are the same
        if char1 == char2:
            continue
            
        pos1 = layout[char1]
        pos2 = layout[char2]
        
        # math.dist is a clean way to get Euclidean distance
        total_distance += math.dist(pos1, pos2)
        
    return total_distance


@dataclass
class SAParams:
    iters: int = 20000
    t0: float = 1000.0   # Initial temperature setting, needs to be high enough
    alpha: float = 0.9999 # geometric decay per iteration (slow cooling is better)


def simulated_annealing(
    text: str,
    layout: Layout,
    params: SAParams,
    rng: random.Random,
) -> Tuple[Layout, float, List[float], List[float]]:
    """Simulated annealing to minimize path-length cost over character swaps.

    Returns best layout, best cost, and two lists:
    - best cost up to now (monotonically decreasing)
    - cost of current solution (may occasionally go up)
    These will be used for plotting.
    """
    # Characters that can be swapped (we keep space fixed)
    movable_chars = list(layout.keys())
    if " " in movable_chars:
        movable_chars.remove(" ")

    current_layout = layout.copy()
    current_cost = path_length_cost(text, current_layout)
    
    best_layout = current_layout.copy()
    best_cost = current_cost
    
    best_trace = [best_cost]
    current_trace = [current_cost]
    
    temp = params.t0

    for i in range(params.iters):
        # 1. Propose a new layout by swapping two random characters
        char1, char2 = rng.sample(movable_chars, 2)
        
        neighbor_layout = current_layout.copy()
        neighbor_layout[char1], neighbor_layout[char2] = neighbor_layout[char2], neighbor_layout[char1]
        
        # 2. Calculate the cost of the new layout
        neighbor_cost = path_length_cost(text, neighbor_layout)
        cost_delta = neighbor_cost - current_cost

        # 3. Decide whether to accept the new layout
        if cost_delta < 0 or rng.random() < math.exp(-cost_delta / temp):
            current_layout = neighbor_layout
            current_cost = neighbor_cost
        
        # 4. Update the best-found solution
        if current_cost < best_cost:
            best_cost = current_cost
            best_layout = current_layout.copy()
            
        # 5. Record history and cool down
        best_trace.append(best_cost)
        current_trace.append(current_cost)
        temp *= params.alpha

        if (i + 1) % 5000 == 0:
            print(f"  Iter {i+1}/{params.iters}: Best Cost={best_cost:.2f}, Temp={temp:.4f}")

    return best_layout, best_cost, best_trace, current_trace

def plot_costs(
    layout: Layout, best_trace: List[float], current_trace: List[float]
) -> None:
    """Generates and saves plots for the cost history and the final layout."""
    out_dir = "." # Save in the current directory

    # --- Plot cost trace ---
    plt.figure(figsize=(10, 5))
    # Plot current_trace first in a lighter color
    plt.plot(current_trace, color='lightsteelblue', alpha=0.7, label='Current Cost')
    plt.plot(best_trace, color='darkblue', lw=1.5, label='Best Cost')
    plt.xlabel("Iteration")
    plt.ylabel("Cost (Total Path Length)")
    plt.title("Cost vs Iteration")
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.tight_layout()
    path = os.path.join(out_dir, "cost_trace.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"Saved: {path}")

    # --- Plot layout scatter ---
    xs, ys, labels = [], [], []
    for ch, (x, y) in layout.items():
        if ch == " ": continue # Don't plot the space label for clarity
        xs.append(x)
        ys.append(y)
        labels.append(ch)
    
    # Add space bar visualization
    space_x, space_y = layout[" "]
    plt.figure(figsize=(8, 4))
    plt.scatter(xs, ys, s=1000, c='#1f77b4', alpha=0.6)
    plt.scatter([space_x], [space_y], s=8000, c='#1f77b4', alpha=0.6, marker='_')

    for x, y, ch in zip(xs, ys, labels):
        plt.text(
            x, y, ch, ha="center", va="center", color="white",
            fontsize=12, weight='bold'
        )
    
    plt.gca().invert_yaxis()
    plt.title("Optimized Keyboard Layout")
    plt.axis("equal")
    plt.axis('off') # Hide axes for a cleaner look
    plt.tight_layout()
    path = os.path.join(out_dir, "layout.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"Saved: {path}")


def load_text(filename) -> str:
    """Loads text from a file or returns a default string if file not found."""
    try:
        if filename is not None:
            with open(filename, "r", encoding="utf-8") as f:
                return f.read()
    except FileNotFoundError:
        print(f"Warning: File '{filename}' not found. Using default text.")
    
    # Fallback demo text
    return (
        "the quick brown fox jumps over the lazy dog\n"
        "pack my box with five dozen liquor jugs\n"
        "this is a simple example text for keyboard layout optimization\n"
        "simulated annealing is a probabilistic technique for approximating\n"
        "the global optimum of a given function\n"
    )
def main() -> None:
    parser = argparse.ArgumentParser(description="Keyboard Layout Optimization")
    parser.add_argument("filename", nargs='?', default=None, help="Path to text file (optional)")
    
    # --- ADD these three lines to define the new arguments ---
    parser.add_argument("--iterations", type=int, default=20000, help="Number of optimization iterations.")
    parser.add_argument("--temp", type=float, default=1000.0, help="Initial temperature for simulated annealing.")
    parser.add_argument("--cooling", type=float, default=0.99985, help="Cooling rate (e.g., 0.999).")
    
    args = parser.parse_args()

    rng = random.Random(0) # Use a fixed seed for reproducibility
    chars = "abcdefghijklmnopqrstuvwxyz "

    # --- Setup and Baseline ---
    layout0 = initial_layout(chars)
    raw_text = load_text(args.filename)
    text = preprocess_text(raw_text, chars)

    baseline_cost = path_length_cost(text, layout0)
    print(f"Baseline (QWERTY assignment) cost: {baseline_cost:.2f}")

    # --- Annealing ---
    # --- CHANGE this line to use the arguments from the command line ---
    params = SAParams(iters=args.iterations, t0=args.temp, alpha=args.cooling)
    
    print(f"Starting simulated annealing for {params.iters} iterations...")
    start = time.time()
    best_layout, best_cost, best_trace, current_trace = simulated_annealing(
        text, layout0, params, rng
    )
    dur = time.time() - start
    
    print("\n--- Optimization Complete ---")
    print(f"Optimized cost: {best_cost:.2f} (Improvement: {(baseline_cost - best_cost):.2f})")
    print(f"Runtime: {dur:.2f}s")

    # --- Visualization and Output ---
    plot_costs(best_layout, best_trace, current_trace)
    
    # Save the final layout to a JSON file
    with open("final_layout.json", "w") as f:
        sorted_layout = {k: v for k, v in sorted(best_layout.items())}
        json.dump(sorted_layout, f, indent=4)
        print("Saved: final_layout.json")

if __name__ == "__main__":
    main()