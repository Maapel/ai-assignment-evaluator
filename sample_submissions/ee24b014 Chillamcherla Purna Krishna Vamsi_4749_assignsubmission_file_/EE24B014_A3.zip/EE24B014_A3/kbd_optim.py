#!/usr/bin/env python3
"""
Keyboard Layout Optimization via Simulated Annealing

Notes:
- Cost is total Euclidean distance between consecutive characters.
- Coordinates are fixed (QWERTY-staggered grid). Optimization swaps assignments.
"""

import argparse
import json
import math
import os
import random
import time
from dataclasses import dataclass
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt  # type: ignore

# Type alias
Layout = Dict[str, Tuple[float, float]]


def qwerty_coordinates(chars: str) -> Layout:
    """Return QWERTY grid coordinates for the provided character set."""
    row0 = "qwertyuiop"
    row1 = "asdfghjkl"
    row2 = "zxcvbnm"

    coords: Layout = {}
    for i, c in enumerate(row0):
        coords[c] = (float(i), 0.0)
    for i, c in enumerate(row1):
        coords[c] = (0.5 + float(i), 1.0)
    for i, c in enumerate(row2):
        coords[c] = (1.0 + float(i), 2.0)
    coords[" "] = (4.5, 3.0)

    # Backfill for requested chars; unknowns get space position.
    space_xy = coords[" "]
    for ch in chars:
        if ch not in coords:
            coords[ch] = space_xy
    return coords


def initial_layout(chars: str) -> Layout:
    """Create an initial layout mapping chars to QWERTY positions."""
    return qwerty_coordinates(chars)


def preprocess_text(text: str, chars: str) -> str:
    """Lowercase and replace unknown characters by space."""
    allowed_chars = set(chars)
    processed_text = [
        char if char in allowed_chars else " " for char in text.lower()
    ]
    return "".join(processed_text)


def path_length_cost(text: str, layout: Layout) -> float:
    """Sum Euclidean distances across consecutive characters in text."""
    total_distance = 0.0
    if len(text) < 2:
        return 0.0

    for i in range(len(text) - 1):
        coord1 = layout[text[i]]
        coord2 = layout[text[i + 1]]
        dx = coord2[0] - coord1[0]
        dy = coord2[1] - coord1[1]
        total_distance += math.sqrt(dx * dx + dy * dy)

    return total_distance


@dataclass
class SAParams:
    iters: int = 50000
    t0: float = 1.0     # Initial temperature
    alpha: float = 0.999  # Geometric decay per iteration
    epoch: int = 1


def simulated_annealing(
    text: str,
    layout: Layout,
    params: SAParams,
    rng: random.Random,
) -> Tuple[Layout, float, List[float], List[float]]:
    """Run simulated annealing to minimize path-length cost."""
    current_layout = layout.copy()
    current_cost = path_length_cost(text, current_layout)

    best_layout = current_layout.copy()
    best_cost = current_cost

    best_trace = [best_cost]
    current_trace = [current_cost]

    temp = params.t0
    chars_to_swap = list(current_layout.keys())

    for i in range(params.iters):
        new_layout = current_layout.copy()
        c1, c2 = rng.sample(chars_to_swap, 2)
        new_layout[c1], new_layout[c2] = new_layout[c2], new_layout[c1]

        new_cost = path_length_cost(text, new_layout)
        cost_diff = new_cost - current_cost

        if cost_diff < 0 or rng.random() < math.exp(-cost_diff / temp):
            current_layout = new_layout
            current_cost = new_cost

        if current_cost < best_cost:
            best_layout = current_layout.copy()
            best_cost = current_cost

        best_trace.append(best_cost)
        current_trace.append(current_cost)

        if (i + 1) % params.epoch == 0:
            temp *= params.alpha

    return best_layout, best_cost, best_trace, current_trace


def plot_costs(
    layout: Layout, best_trace: List[float], current_trace: List[float]
) -> None:
    out_dir = "."

    # Plot cost trace
    plt.figure(figsize=(6, 3))
    plt.plot(best_trace, lw=1.5, label="Best Cost")
    plt.plot(current_trace, lw=1.5, label="Current Cost")
    plt.xlabel("Iteration")
    plt.ylabel("Cost")
    plt.title("Cost Trace")
    plt.legend()
    plt.tight_layout()
    path = os.path.join(out_dir, "cost_trace.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"Saved: {path}")

    # Plot layout scatter
    xs, ys, labels = [], [], []
    for ch, (x, y) in layout.items():
        xs.append(x)
        ys.append(y)
        labels.append(ch)

    plt.figure(figsize=(6, 3))
    plt.scatter(xs, ys, s=250, c="#1f77b4")
    for x, y, ch in zip(xs, ys, labels):
        plt.text(
            x,
            y,
            ch,
            ha="center",
            va="center",
            color="white",
            fontsize=9,
            bbox=dict(boxstyle="round,pad=0.15", fc="#1f77b4", ec="none", alpha=0.9),
        )
    plt.gca().invert_yaxis()
    plt.title("Optimized Layout")
    plt.axis("equal")
    plt.tight_layout()
    path = os.path.join(out_dir, "layout.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"Saved: {path}")


def load_text(filename: str | None) -> str:
    if filename is not None:
        with open(filename, "r", encoding="utf-8") as f:
            return f.read()
    return (
        "the quick brown fox jumps over the lazy dog\n"
        "APL is the best course ever\n"
    )


def main(filename: str | None = None) -> None:
    rng = random.Random(0)
    chars = "abcdefghijklmnopqrstuvwxyz "

    # Initial assignment - QWERTY
    layout0 = initial_layout(chars)

    # Prepare text
    raw_text = load_text(filename)
    text = preprocess_text(raw_text, chars)

    baseline_cost = path_length_cost(text, layout0)
    print(f"Baseline (QWERTY assignment) cost: {baseline_cost:.4f}")

    params = SAParams(iters=50000, t0=1.0, alpha=0.999)
    start = time.time()
    best_layout, best_cost, best_trace, current_trace = simulated_annealing(
        text, layout0, params, rng
    )
    dur = time.time() - start
    print(
        f"Optimized cost: {best_cost:.4f}  (improvement {(baseline_cost - best_cost):.4f})"
    )
    print(f"Runtime: {dur:.2f}s over {params.iters} iterations")

    # Save final layout to JSON
    with open("layout.json", "w", encoding="utf-8") as f:
        json.dump({k: list(v) for k, v in best_layout.items()}, f, indent=2)
    print("Saved: layout.json")

    plot_costs(best_layout, best_trace, current_trace)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Keyboard layout optimization")
    parser.add_argument("--file", "-f", help="Input text file", default=None)
    args = parser.parse_args()
    main(args.file)
