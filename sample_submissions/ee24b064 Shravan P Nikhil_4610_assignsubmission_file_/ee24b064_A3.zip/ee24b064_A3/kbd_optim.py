#!/usr/bin/env python3
"""kbd_optim.py
Final submission script for Keyboard Layout Optimization (Simulated Annealing).

Usage (examples):
    python3 kbd_optim.py --file sample_text.txt --iters 20000 --t0 1.0 --alpha 0.9998 --seed 0 --outdir outputs --roll ee24b064

Outputs (in outdir):
 - layout.png        : scatter plot of final layout
 - cost_trace.png    : best/current cost vs iteration
 - final_layout.json : mapping char -> (x,y) for final layout
 - readme.pdf        : short report with figures
"""

import argparse
import json
import math
import os
import random
import string
import time
from dataclasses import dataclass
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt  # type: ignore


Point = Tuple[float, float]
Layout = Dict[str, Point]


def qwerty_coordinates(chars: str) -> Layout:
    """Return QWERTY grid coordinates for the provided character set.

    The grid is a simple staggered layout (units are arbitrary):
    - Row 0: qwertyuiop at y=0, x in [0..9]
    - Row 1: asdfghjkl at y=1, x in [0.5..8.5]
    - Row 2: zxcvbnm at y=2, x in [1..6]
    - Space at (4.5, 3)
    Characters not present in the grid default to the space position.
    """
    row0 = "qwertyuiop"
    row1 = "asdfghjkl"
    row2 = "zxcvbnm"
    coords: Layout = {}
    for i, c in enumerate(row0):
        coords[c] = (float(i), 0.0)
    for i, c in enumerate(row1):
        coords[c] = (0.5 + float(i), 1.0)
    for i, c in enumerate(row2):
        coords[c] = (1.0 + float(i), 2.0)
    coords[" "] = (4.5, 3.0)

    # Backfill for requested chars; unknowns get space position.
    space_xy = coords[" "]
    for ch in chars:
        if ch not in coords:
            coords[ch] = space_xy
    return coords



def initial_layout() -> Layout:
    """Create an initial layout mapping chars to some arbitrary positions of letters."""

    # Start with identity for letters and space; others mapped to space.
    base_keys = "abcdefghijklmnopqrstuvwxyz "

    # Get coords - or use coords of space as default
    layout = qwerty_coordinates(base_keys)
    return layout


def preprocess_text(text: str, chars: str) -> str:
    """Lowercase and filter to the allowed character set; map others to space."""
    allowed = set(chars)
    text = text.lower()
    out = []
    for ch in text:
        if ch in allowed:
            out.append(ch)
        else:
            out.append(" ")
    return "".join(out)

def dist(a: Point, b: Point) -> float:
    return math.hypot(a[0]-b[0], a[1]-b[1])

def path_length_cost(text: str, layout: Layout) -> float:
    """Sum Euclidean distances across consecutive characters in text."""
    if not text:
        return 0.0
    cost = 0.0
    prev = text[0]
    for ch in text[1:]:
        cost += dist(layout.get(prev, layout[" "]), layout.get(ch, layout[" "]))
        prev = ch
    return cost

@dataclass
class SAParams:
    iters: int = 50000
    t0: float = 1.0  # Initial temperature setting
    alpha: float = 0.999  # geometric decay per iteration
    epoch: int = 1  # iterations per temperature step (1 = per-iter decay)


def simulated_annealing(text: str, layout: Layout, chars: str, params: SAParams, rng: random.Random)-> Tuple[Layout, float, List[float], List[float]]:
    """Simulated annealing to minimize path-length cost over character swaps.

    Returns best layout, best cost, and two lists:
    - best cost up to now (monotonically decreasing)
    - cost of current solution (may occasionally go up)
    These will be used for plotting
    """
    current = dict(layout)
    best = dict(current)
    current_cost = path_length_cost(text, current)
    best_cost = current_cost
    best_trace = []
    current_trace = []
    T = params.t0

    char_list = list(chars)

    for i in range(params.iters):
        # Propose swap of two characters (allow space to move too)
        a, b = rng.sample(char_list, 2)
        # swap their coords
        coord_a = current[a]
        coord_b = current[b]
        current[a], current[b] = coord_b, coord_a
        new_cost = path_length_cost(text, current)
        delta = new_cost - current_cost
        accept = False
        if delta <= 0.0 or rng.random() < math.exp(-delta / max(T, 1e-12)):
            accept = True
            current_cost = new_cost
            if new_cost < best_cost:
                best_cost = new_cost
                best = dict(current)
        else:
            # revert
            current[a], current[b] = coord_a, coord_b
        # record
        best_trace.append(best_cost)
        current_trace.append(current_cost)
        # temperature decay (geometric)
        T *= params.alpha

    return best, best_cost, best_trace, current_trace

def plot_costs(layout: Layout, best_trace: List[float], current_trace: List[float], out_dir: str) -> None:
    os.makedirs(out_dir, exist_ok=True)

    # --- Plot cost trace ---
    plt.figure(figsize=(8, 3))
    plt.plot(best_trace, lw=1.5, label="Best Cost")
    plt.plot(current_trace, lw=1.0, alpha=0.7, label="Current Cost")
    plt.xlabel("Iteration")
    plt.ylabel("Cost (path length)")
    plt.legend()
    plt.title("Cost vs Iteration")
    plt.tight_layout()
    cost_path = os.path.join(out_dir, "cost_trace.png")
    plt.savefig(cost_path, dpi=150)
    plt.close()
    print(f"Saved: {cost_path}")

    # --- Plot layout scatter ---
    xs, ys, labels = [], [], []
    for ch, (x, y) in sorted(layout.items(), key=lambda kv: (kv[1][1], kv[1][0])):
        xs.append(x)
        ys.append(y)
        labels.append(ch)

    plt.figure(figsize=(8, 3))
    plt.scatter(xs, ys, s=260, c="#1f77b4")
    for x, y, ch in zip(xs, ys, labels):
        plt.text(
            x, y, ch, ha="center", va="center", color="white",
            fontsize=10, bbox=dict(boxstyle='round,pad=0.15', fc="#1f77b4", ec="none")
        )
    plt.gca().invert_yaxis()
    plt.axis("equal")
    plt.title("Final layout (characters placed at coordinates)")
    plt.tight_layout()
    layout_path = os.path.join(out_dir, "layout.png")
    plt.savefig(layout_path, dpi=150)
    plt.close()
    print(f"Saved: {layout_path}")
def save_json_layout(layout: Layout, outpath: str):
    j = {ch: [float(x), float(y)] for ch,(x,y) in layout.items()}
    with open(outpath, "w", encoding="utf-8") as f:
        json.dump(j, f, indent=2)
    return outpath

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--file", default=None, help="Path to text file to optimize for")
    parser.add_argument("--iters", type=int, default=20000)
    parser.add_argument("--t0", type=float, default=1.0)
    parser.add_argument("--alpha", type=float, default=0.9999)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--outdir", default="outputs")
    parser.add_argument("--roll", default="ee24b064")
    args = parser.parse_args()

    chars = "abcdefghijklmnopqrstuvwxyz "

    layout0 = qwerty_coordinates(chars)

    if args.file is not None:
        with open(args.file, "r", encoding="utf-8") as f:
            raw = f.read()
    else:
        raw = "the quick brown fox jumps over the lazy dog\nthis is sample text for keyboard optimization\n"

    text = preprocess_text(raw, chars)
    baseline_cost = path_length_cost(text, layout0)

    params = SAParams(iters=args.iters, t0=args.t0, alpha=args.alpha)
    rng = random.Random(args.seed)
    start = time.time()
    best_layout, best_cost, best_trace, current_trace = simulated_annealing(text, layout0, chars, params, rng)
    dur = time.time() - start

    os.makedirs(args.outdir, exist_ok=True)

    #Save plots
    plot_costs(best_layout, best_trace, current_trace, args.outdir)


    layout_img = os.path.join(args.outdir, "layout.png")
    cost_img = os.path.join(args.outdir, "cost_trace.png")
    #Save json layout
    json_path = save_json_layout(best_layout, os.path.join(args.outdir, "final_layout.json"))

    # summary_path = os.path.join(args.outdir, "summary.json")
    # print("Wrote outputs to", args.outdir)
if __name__ == "__main__":
    main()