#!/usr/bin/env python3
"""
Keyboard Layout Optimization via Simulated Annealing
DEVELOPER: VP AVINAASH EE24B007

Notes:
- Cost is total Euclidean distance between consecutive characters.
- Coordinates are fixed (QWERTY-staggered grid). Optimization swaps assignments.
- Temperature is fixed for the #no. of epochs for each iterations 
- Records best and current cost traces for each iterations.
"""

import math
import os
import random
import time
from dataclasses import dataclass
from typing import Dict, List, Tuple
import matplotlib.pyplot as plt 

Point = Tuple[float, float]
Layout = Dict[str, Point]

def qwerty_coordinates(chars: str) -> Layout:
    """Return QWERTY grid coordinates for the provided character set.
    Characters not present in the grid default to the space position.
    """
    row0 = "qwertyuiop"
    row1 = "asdfghjkl"
    row2 = "zxcvbnm"

    coords: Layout = {}
    for i, c in enumerate(row0):
        coords[c] = (float(i), 0.0)
    for i, c in enumerate(row1):
        coords[c] = (0.5 + float(i), 1.0)
    for i, c in enumerate(row2):
        coords[c] = (1.0 + float(i), 2.0)
    coords[" "] = (4.5, 3.0)

    # Backfill for requested chars; unknowns get space position.
    space_xy = coords[" "]
    for ch in chars:
        if ch not in coords:
            coords[ch] = space_xy
    return coords

def initial_layout() -> Layout:
    """Create an initial layout mapping chars to some arbitrary positions of letters."""

    # Start with identity for letters and space; others mapped to space.
    # Get coords - or use coords of space as default
    base_key = "abcdefghijklmnopqrstuvwxyz "
    layout = qwerty_coordinates(base_key)
    return layout

def layout_cost(text: str, layout: Layout) -> float:
    """Sum Euclidean distances across consecutive characters in text."""
    return sum((( layout[text[i]][0] - layout[text[i+1]][0] )**2 + 
                 ( layout[text[i]][1] - layout[text[i+1]][1] )**2)**0.5 for i in range(len(text)-1)) 

@dataclass
class SAParams:
    iters: int = 500
    t0: float = 1.0  # Initial temperature setting
    alpha: float = 0.999  # geometric decay per iteration
    epoch: int = 1  # iterations per temperature step (1 = per-iter decay)

def get_neighbour(layout, rng):
    new_layout = layout.copy()
    i, j = rng.sample(list(new_layout.keys()), 2)       #Sample 2 random points to get the neighbour
    new_layout[i] , new_layout[j] = new_layout[j], new_layout[i]
    return new_layout


def simulated_annealing(text: str,layout: Layout,params: SAParams,rng: random.Random) -> Tuple[Layout, float, List[float], List[float]]:
    ''' Core optimising step. 
    Optimised the cost using the simualted annealing optimiser with initial qwert layout
    For each iteration it keeps the temp constant for #epochs and computes the best and current cost
    '''
    min_temp_threshold = 1e-10          #min acceptable temperature

    temp = params.t0 
    num_iterations = params.iters
    cooling_rate = params.alpha
    epochs = params.epoch

    current_layout = dict(layout)           #initial layout
    current_cost = layout_cost(text, current_layout)
    best_layout = dict(current_layout)
    best_cost = current_cost

    costs = [current_cost]              #monitor the trace for plotting
    best_costs = [best_cost]

    for _ in range(num_iterations):
        for _ in range(epochs):
            neighbour_layout = get_neighbour(current_layout, rng)
            neighbour_cost = layout_cost(text, neighbour_layout)

            val = (current_cost - neighbour_cost)   #accept if cost dec or with some probability
            if neighbour_cost < current_cost or rng.random() < math.exp(val/max(temp, min_temp_threshold)):
                current_layout = neighbour_layout
                current_cost = neighbour_cost
                
                if current_cost < best_cost:        #check for best cost
                    best_layout = dict(current_layout)
                    best_cost = current_cost
            
        costs.append(current_cost)          #update for every iteration
        best_costs.append(best_cost)
        temp *= cooling_rate 

    return best_layout, best_cost, best_costs, costs

def plot_costs(layout: Layout, best_trace: List[float], current_trace: List[float], params: SAParams) -> None:
    out_dir = "."

    plt.figure(figsize=(8, 5))
    plt.plot(best_trace, lw=2.0, color="tab:blue", label="Best Cost")
    plt.plot(current_trace, lw=1.2, color="tab:orange", alpha=0.8, label="Current Cost")

    plt.xlabel("Iteration", fontsize=11)
    plt.ylabel("Cost", fontsize=11)
    plt.title(f"Best Cost vs. Iteration (Simulated Annealing)\niter {params.iters} ; t0 {params.t0} ; epoch {params.epoch}", 
              fontsize=12, pad=10)

    plt.grid(True, which="both", ls="--", lw=0.6, alpha=0.7)
    plt.legend(frameon=True, loc="best", fontsize=10)
    plt.tight_layout()

    path = os.path.join(out_dir, "cost_trace.png")
    plt.savefig(path, dpi=200, bbox_inches="tight")
    plt.close()
    print(f"Saved: {path}")


    # Plot layout scatter
    xs, ys, labels = [], [], []
    for ch, (x, y) in layout.items():
        xs.append(x)
        ys.append(y)
        labels.append(ch)

    plt.figure(figsize=(6, 3))
    plt.scatter(xs, ys, s=250, c="#0c2435")
    for x, y, ch in zip(xs, ys, labels):
        plt.text(x, y, ch.upper(), ha="center", va="center", color="white", fontsize=8,
            bbox=dict(boxstyle="round,pad=0.15", fc="#0c2435", ec="none", alpha=0.9),)
    plt.gca().invert_yaxis()
    plt.title(f"Optimized Layout\niter {params.iters} ; t0 {params.t0} ; epoch {params.epoch}")
    plt.axis("equal")
    plt.tight_layout()
    path = os.path.join(out_dir, "layout.png")
    plt.savefig(path, dpi=150)

    plt.close()
    print(f"Saved: {path}")

def preprocess_text(text: str, chars: str) -> str:
    ''' Preprocess the text by filtering out characters only in chars'''
    return ''.join([' ' if char not in chars else char for char in text.lower() ])

def load_text(filename) -> str:
    ''' Loads the text file and reads it'''
    if filename is not None:
        with open(filename, "r", encoding="utf-8") as f:
            return f.read()
    
    return (
        "the quick brown fox jumps over the lazy dog\n"
        "APL is the best course ever\n"
    )


def main(filename: str | None = None) -> None:
    rng = random.Random(0)
    chars = "abcdefghijklmnopqrstuvwxyz "

    layout0 = initial_layout()  # Initial assignment - QWERTY

    raw_text = load_text(filename)   # Prepare text and evaluate baseline
    text = preprocess_text(raw_text, chars)

    baseline_cost = layout_cost(text, layout0)
    print(f"Baseline (QWERTY assignment) cost: {baseline_cost:.4f}")

    params = SAParams(iters=4000, t0=5.0, alpha=0.999, epoch=2)   #Annealing - give parameter values

    start = time.time()
    best_layout, best_cost, best_trace, current_trace = simulated_annealing(text, layout0, params, rng)
    dur = time.time() - start

    print(f"Optimized cost: {best_cost:.4f}  (improvement {(baseline_cost - best_cost):.4f})")
    print(f"Runtime: {dur:.2f}s over iterations")
    plot_costs(best_layout, best_trace, current_trace, params)

if __name__ == "__main__":
    main()