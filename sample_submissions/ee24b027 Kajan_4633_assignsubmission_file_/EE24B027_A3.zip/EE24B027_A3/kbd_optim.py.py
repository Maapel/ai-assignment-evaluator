#!/usr/bin/env python3
"""
Keyboard Layout Optimization via Simulated Annealing


Notes:
- Cost is total Euclidean distance between consecutive characters.
- Coordinates are fixed (QWERTY-staggered grid). Optimization swaps assignments.

This base code uses Python "types" - these are optional, but very helpful
for debugging and to help with editing.

"""

import argparse
import json
import math
import os
import random
from dataclasses import dataclass
from typing import Dict, List, Tuple
import time

import matplotlib.pyplot as plt  # type: ignore


Point = Tuple[float, float]
Layout = Dict[str, Point]


def qwerty_coordinates(chars: str) -> Layout:
    """Return QWERTY grid coordinates for the provided character set.

    The grid is a simple staggered layout (units are arbitrary):
    - Row 0: qwertyuiop at y=0, x in [0..9]
    - Row 1: asdfghjkl at y=1, x in [0.5..8.5]
    - Row 2: zxcvbnm at y=2, x in [1..6]
    - Space at (4.5, 3)
    Characters not present in the grid default to the space position.
    """
    row0 = "qwertyuiop"
    row1 = "asdfghjkl"
    row2 = "zxcvbnm"

    coords: Layout = {}
    for i, c in enumerate(row0):
        coords[c] = (float(i), 0.0)
    for i, c in enumerate(row1):
        coords[c] = (0.5 + float(i), 1.0)
    for i, c in enumerate(row2):
        coords[c] = (1.0 + float(i), 2.0)
    coords[" "] = (4.5, 3.0)

    # Backfill for requested chars; unknowns get space position.
    space_xy = coords[" "]
    for ch in chars:
        if ch not in coords:
            coords[ch] = space_xy
    return coords


def initial_layout() -> Layout:
    """Create an initial layout mapping chars to some arbitrary positions of letters."""

    # Start with identity for letters and space; others mapped to space.
    base_keys = "abcdefghijklmnopqrstuvwxyz "

    # Get coords - or use coords of space as default
    layout = qwerty_coordinates(base_keys)
    return layout


def preprocess_text(text: str, chars: str) -> str:
    """Lowercase and filter to the allowed character set; map others to space."""
    allowed_chars = set(chars) # e.g., 'abcdefghijklmnopqrstuvwxyz '
    result = []
    for i in text:
        ch = i.lower() #convert everything to lowercase
        if ch in allowed_chars:
            result.append(ch)
        else:
            result.append(" ") #put space instead of non alphabetical characters
    return "".join(result)

def path_length_cost(text: str, layout: Layout) -> float:
    """Sum Euclidean distances across consecutive characters in text."""
    total_distance = 0.0
    
    # Iterate through consecutive character pairs
    for i in range(len(text) - 1):
        char1 = text[i]
        char2 = text[i + 1]

        # Get coordinates for the two characters
        (x1, y1) = layout[char1]
        (x2, y2) = layout[char2]

        # Calculate Euclidean distance
        dx = x2 - x1
        dy = y2 - y1
        distance = math.sqrt(dx**2 + dy**2)
        
        total_distance += distance
            
    return total_distance
    
    
        
            


######
# Define any other useful functions, such as to create new layout etc.
######
def swap_layout_chars(current_layout: Layout, char1: str, char2: str) -> Layout:
    """Creates a new layout by swapping the coordinates assigned to two characters."""
    new_layout = current_layout.copy()
    
    # Get the coordinates currently assigned to char1 and char2
    coord1 = current_layout[char1]
    coord2 = current_layout[char2]
    
    # Swap the assignments in the new layout
    new_layout[char1] = coord2
    new_layout[char2] = coord1
    
    return new_layout


# Dataclass is like a C struct - you can use it just to store data if you wish
# It provides some convenience functions for assignments, printing etc.
@dataclass
class SAParams:
    iters: int = 50000
    t0: float = 1.0  # Initial temperature setting
    alpha: float = 0.999  # geometric decay per iteration
    epoch: int = 1  # iterations per temperature step (1 = per-iter decay)


def simulated_annealing(
    text: str,
    layout0: Layout,
    params: SAParams,
    rng: random.Random,
) -> Tuple[Layout, float, List[float], List[float]]:
    """Simulated annealing to minimize path-length cost over character swaps.

    Returns best layout, best cost, and two lists:
    - best cost up to now (monotonically decreasing)
    - cost of current solution (may occasionally go up)
    These will be used for plotting
    """
    
    current_layout = layout0
    current_cost = path_length_cost(text, current_layout)

    best_layout = current_layout
    best_cost = current_cost
    
    # Get the list of characters to be optimized (those with unique coordinates)
    chars_to_swap = list(layout0.keys()) 
    
    T = params.t0
    
    # Tracing lists for plotting
    best_trace = [best_cost]
    current_trace = [current_cost]

    for k in range(1, params.iters + 1):
        #Generate a candidate new layout (neighbor) by swapping two random characters
        char1, char2 = rng.sample(chars_to_swap, 2)
        new_layout = swap_layout_chars(current_layout, char1, char2)
        new_cost = path_length_cost(text, new_layout)
        
        cost_delta = new_cost - current_cost
        
        
        # Always accept if better (cost_delta <= 0)
        # Accept probabilistically if worse (cost_delta > 0)
        acceptance_prob = math.exp(-cost_delta / T) if cost_delta > 0 else 1.0
        
        if acceptance_prob >= 1.0 or rng.random() < acceptance_prob:
            # Accept the new layout
            current_layout = new_layout
            current_cost = new_cost
            
            # Update best layout if needed
            if current_cost < best_cost:
                best_cost = current_cost
                best_layout = current_layout

        # Geometric decay
        if k % params.epoch == 0:
            T = params.t0 * (params.alpha ** (k / params.epoch))
        
        # Record traces
        best_trace.append(best_cost)
        current_trace.append(current_cost)

    return best_layout, best_cost, best_trace, current_trace

def plot_costs(
    layout: Layout, best_trace: List[float], current_trace: List[float], baseline_cost: float
) -> None:
    """Plots cost trace and the final layout."""

    out_dir = "."
    
    # --- Plot cost trace ---
    if best_trace and current_trace:
        plt.figure(figsize=(8, 4))
        plt.plot(best_trace, lw=1.5, label="Best Cost (Monotonic)")
        plt.plot(current_trace, lw=1.5, alpha=0.6, label="Current Cost")
        # Add baseline for context
        plt.axhline(baseline_cost, color='r', linestyle='--', lw=1.0, label=f"Baseline Cost ({baseline_cost:.2f})")
        
        plt.xlabel("Iteration")
        plt.ylabel("Cost (Euclidean Distance)")
        plt.title("Keyboard Layout Optimization: Cost Trace")
        plt.legend()
        plt.grid(True, linestyle=':', alpha=0.7)
        plt.tight_layout()
        path = os.path.join(out_dir, f"cost_trace.png")
        plt.savefig(path, dpi=150)
        plt.close()
        print(f"Saved: {path}")

    # --- Plot layout scatter ---
    xs, ys, labels = [], [], []
    for ch, (x, y) in layout.items():
        # Only plot characters that were part of the initial QWERTY layout
        if ch in "abcdefghijklmnopqrstuvwxyz ":
            xs.append(x)
            ys.append(y)
            labels.append(ch)

    plt.figure(figsize=(6, 3))
    plt.scatter(xs, ys, s=250, c="#1f77b4")
    for x, y, ch in zip(xs, ys, labels):
        # Annotation for the character label
        plt.text(
            x,
            y,
            ch.upper(), # Displaying uppercase for visual clarity
            ha="center",
            va="center",
            color="white",
            fontsize=9,
            bbox=dict(boxstyle="round,pad=0.15", fc="#1f77b4", ec="none", alpha=0.9),
        )
    
    plt.gca().invert_yaxis() # Invert Y-axis to match typical keyboard layout view
    plt.title("Optimized Layout")
    plt.xlabel("X Coordinate")
    plt.ylabel("Y Coordinate (Row)")
    plt.axis("equal") # Ensure aspect ratio is correct
    plt.xticks(list(range(10)))
    plt.yticks(list(range(4)))
    plt.tight_layout()
    path = os.path.join(out_dir, f"layout.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"Saved: {path}")
    
    
    

def load_text(filename) -> str:
    """Loads text from a file or uses a fallback demo text."""
    # Check if a filename was provided AND if that file actually exists
    if filename is not None and os.path.exists(filename):
        with open(filename, "r", encoding="utf-8") as f:
            return f.read()
    
    # If filename is None OR the file doesn't exist
    return (
        "the quick brown fox jumps over the lazy dog\n"
        "APL is the best course ever\n"
    )

# --- HARDCODED PARAMETERS ---
SA_ITERS = 50000    # Total iterations
SA_T0 = 1.0         # Initial Temperature
SA_ALPHA = 0.9999   # Cooling Rate
SA_EPOCH = 1        # Iterations per temperature step
# ----------------------------

def main() -> None:
    # Setup
    rng = random.Random(0) # Fixed seed for reproducibility
    chars = "abcdefghijklmnopqrstuvwxyz " 

    # Initial assignment - QWERTY
    layout0 = initial_layout()
    
    # Load text 
    raw_text = load_text(None) 
    text = preprocess_text(raw_text, chars)
    
    if not text:
        print("Error: Preprocessed text is empty. Cannot run optimization.")
        return

    # Baseline Evaluation
    baseline_cost = path_length_cost(text, layout0)
    print(f"\n--- Optimization Setup ---")
    print(f"Total characters in text for analysis: {len(text)}")
    print(f"Baseline (QWERTY assignment) cost: {baseline_cost:.4f}")

    # Annealing Execution (using hardcoded parameters)
    params = SAParams(iters=SA_ITERS, t0=SA_T0, alpha=SA_ALPHA, epoch=SA_EPOCH)
    print(f"SA Parameters: Iters={params.iters}, T0={params.t0}, alpha={params.alpha}")
    
    print(f"\n--- Starting Simulated Annealing ---")
    start = time.time()
    best_layout, best_cost, best_trace, current_trace = simulated_annealing(
        text, layout0, params, rng
    )
    dur = time.time() - start
    
    # Results
    print(f"\n--- Optimization Results ---")
    print(f"Optimized cost: {best_cost:.4f}")
    print(f"Improvement over baseline: {(baseline_cost - best_cost):.4f}")
    print(f"Runtime: {dur:.2f}s over {params.iters} iterations")

    # Plotting
    plot_costs(best_layout, best_trace, current_trace, baseline_cost)


if __name__ == "__main__":
    main()
