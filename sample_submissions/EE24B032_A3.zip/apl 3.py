#!/usr/bin/env python3
"""
Keyboard Layout Optimization via Simulated Annealing
Assignment Solution
"""

import argparse
import math
import os
import random
import string
import time
import json
from dataclasses import dataclass
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt  # type: ignore

Point = Tuple[float, float]
Layout = Dict[str, Point]


def qwerty_coordinates(chars: str) -> Layout:
    """Return QWERTY grid coordinates for the provided character set."""
    row0 = "qwertyuiop"
    row1 = "asdfghjkl"
    row2 = "zxcvbnm"

    coords: Layout = {}
    for i, c in enumerate(row0):
        coords[c] = (float(i), 0.0)
    for i, c in enumerate(row1):
        coords[c] = (0.5 + float(i), 1.0)
    for i, c in enumerate(row2):
        coords[c] = (1.0 + float(i), 2.0)
    coords[" "] = (4.5, 3.0)

    space_xy = coords[" "]
    for ch in chars:
        if ch not in coords:
            coords[ch] = space_xy
    return coords


def initial_layout(chars: str) -> Layout:
    """Initial identity layout mapping each char to QWERTY coords."""
    return qwerty_coordinates(chars)


def preprocess_text(text: str, chars: str) -> str:
    """Lowercase and keep only allowed characters, others → space."""
    text = text.lower()
    allowed = set(chars)
    return "".join(ch if ch in allowed else " " for ch in text)


def path_length_cost(text: str, layout: Layout) -> float:
    """Total Euclidean distance traveled over consecutive characters."""
    dist = 0.0
    for i in range(len(text) - 1):
        x1, y1 = layout[text[i]]
        x2, y2 = layout[text[i + 1]]
        dist += math.dist((x1, y1), (x2, y2))
    return dist


@dataclass
class SAParams:
    iters: int = 50000
    t0: float = 1.0
    alpha: float = 0.999
    epoch: int = 1


def swap_chars(layout: Layout, rng: random.Random) -> Layout:
    """Return a new layout by swapping two characters."""
    new_layout = layout.copy()
    keys = list(new_layout.keys())
    a, b = rng.sample(keys, 2)
    new_layout[a], new_layout[b] = new_layout[b], new_layout[a]
    return new_layout


def simulated_annealing(
    text: str,
    layout: Layout,
    params: SAParams,
    rng: random.Random,
) -> Tuple[Layout, float, List[float], List[float]]:
    """Simulated annealing optimization."""
    current_layout = layout
    current_cost = path_length_cost(text, current_layout)
    best_layout = current_layout
    best_cost = current_cost

    best_trace, current_trace = [], []

    T = params.t0
    for it in range(params.iters):
        # Propose move
        new_layout = swap_chars(current_layout, rng)
        new_cost = path_length_cost(text, new_layout)

        # Acceptance criterion
        if new_cost < current_cost or rng.random() < math.exp(-(new_cost - current_cost) / T):
            current_layout, current_cost = new_layout, new_cost
            if new_cost < best_cost:
                best_layout, best_cost = new_layout, new_cost

        best_trace.append(best_cost)
        current_trace.append(current_cost)

        # Temperature decay
        if (it + 1) % params.epoch == 0:
            T *= params.alpha

    return best_layout, best_cost, best_trace, current_trace


def plot_costs(layout: Layout, best_trace: List[float], current_trace: List[float]) -> None:
    out_dir = "."
    plt.figure(figsize=(6, 3))
    plt.plot(best_trace, label="Best cost")
    plt.plot(current_trace, label="Current cost", alpha=0.7)
    plt.xlabel("Iteration")
    plt.ylabel("Cost")
    plt.legend()
    plt.title("Cost vs Iteration")
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "cost_trace.png"), dpi=150)
    plt.close()

    xs, ys, labels = [], [], []
    for ch, (x, y) in layout.items():
        xs.append(x)
        ys.append(y)
        labels.append(ch)

    plt.figure(figsize=(6, 3))
    plt.scatter(xs, ys, s=250, c="#1f77b4")
    for x, y, ch in zip(xs, ys, labels):
        plt.text(
            x, y, ch,
            ha="center", va="center", color="white", fontsize=9,
            bbox=dict(boxstyle="round,pad=0.15", fc="#1f77b4", ec="none", alpha=0.9),
        )
    plt.gca().invert_yaxis()
    plt.axis("equal")
    plt.title("Optimized Layout")
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "layout.png"), dpi=150)
    plt.close()


def load_text(filename: str | None) -> str:
    if filename and os.path.exists(filename):
        with open(filename, "r", encoding="utf-8") as f:
            return f.read()
    return "the quick brown fox jumps over the lazy dog " * 50


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-f", "--file", type=str, default=None, help="Input text file")
    parser.add_argument("-i", "--iters", type=int, default=20000, help="Iterations")
    parser.add_argument("-t0", "--t0", type=float, default=1.0, help="Initial temperature")
    parser.add_argument("-a", "--alpha", type=float, default=0.999, help="Cooling rate")
    args = parser.parse_args()

    rng = random.Random(0)
    chars = string.ascii_lowercase + " "

    raw_text = load_text(args.file)
    text = preprocess_text(raw_text, chars)

    layout0 = initial_layout(chars)
    baseline_cost = path_length_cost(text, layout0)
    print(f"Baseline (QWERTY) cost: {baseline_cost:.4f}")

    params = SAParams(iters=args.iters, t0=args.t0, alpha=args.alpha)
    start = time.time()
    best_layout, best_cost, best_trace, current_trace = simulated_annealing(
        text, layout0, params, rng
    )
    dur = time.time() - start

    print(f"Optimized cost: {best_cost:.4f}")
    print(f"Improvement: {baseline_cost - best_cost:.4f}")
    print(f"Runtime: {dur:.2f}s")

    # Save layout as JSON
    with open("final_layout.json", "w") as f:
        json.dump(best_layout, f, indent=2)

    plot_costs(best_layout, best_trace, current_trace)


if __name__ == "__main__":
    main()
