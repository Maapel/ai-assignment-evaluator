#!/usr/bin/env python3
"""
Keyboard Layout Optimization via Simulated Annealing


Notes:
- Cost is total Euclidean distance between consecutive characters.
- Coordinates are fixed (QWERTY-staggered grid). Optimization swaps assignments.

This base code uses Python "types" - these are optional, but very helpful
for debugging and to help with editing.

"""

import argparse
import json
import math
import os
import random
import string
import time
from dataclasses import dataclass
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt  # type: ignore


Point = Tuple[float, float]
Layout = Dict[str, Point]


def qwerty_coordinates(chars: str) -> Layout:          # initial layout for qwerty.
    """Return QWERTY grid coordinates for the provided character set.

    The grid is a simple staggered layout (units are arbitrary):
    - Row 0: qwertyuiop at y=0, x in [0..9]
    - Row 1: asdfghjkl at y=1, x in [0.5..8.5]
    - Row 2: zxcvbnm at y=2, x in [1..6]
    - Space at (4.5, 3)
    Characters not present in the grid default to the space position.
    """
    row0 = "qwertyuiop"
    row1 = "asdfghjkl"
    row2 = "zxcvbnm"

    coords: Layout = {}
    for i, c in enumerate(row0):
        coords[c] = (float(i), 0.0)
    for i, c in enumerate(row1):
        coords[c] = (0.5 + float(i), 1.0)
    for i, c in enumerate(row2):
        coords[c] = (1.0 + float(i), 2.0)
    coords[" "] = (4.5, 3.0)

    # Backfill for requested chars; unknowns get space position.
    space_xy = coords[" "]
    for ch in chars:
        if ch not in coords:
            coords[ch] = space_xy
    return coords


def initial_layout() -> Layout:     #calling the above helper func
    """Create an initial layout mapping chars to some arbitrary positions of letters."""

    # Start with identity for letters and space; others mapped to space.
    base_keys = "abcdefghijklmnopqrstuvwxyz "

    # Get coords - or use coords of space as default
    layout = qwerty_coordinates(base_keys)
    return layout


def preprocess_text(text: str, chars: str) -> str:
    """Lowercase and filter to the allowed character set; map others to space."""

    text = text.lower()    #conversion to lowercase.
    chars_set = set(chars) #str-> set conversion
    processed = "".join(ch if ch in chars_set else " " for ch in text)  #replacing ch other than letters with space
    return processed

    


def path_length_cost(text: str, layout: Layout) -> float:
    """Sum Euclidean distances across consecutive characters in text."""

    total = 0.0
    if not text:    #if text is empty->return 0
        return total

    prev_pos = layout.get(text[0], layout[" "])  #stores first ch pos and returns pos from initial layout, if ch is not in allowed char, returns pos of spacebar
    for ch in text[1:]:                          #from ch indexed 1 to len(text)-1
        pos = layout.get(ch, layout[" "])        #get pos
        dist = math.hypot(pos[0] - prev_pos[0], pos[1] - prev_pos[1]) #math.hypot(dx, dy) → returns sqrt(dx*dx + dy*dy)- calculating eucldiean dist between consecutive points.
        total += dist                            #adding to total
        prev_pos = pos                           #incrementing the prev pos to current pos.
    return total



######
# Define any other useful functions, such as to create new layout etc.
######


# Dataclass is like a C struct - you can use it just to store data if you wish
# It provides some convenience functions for assignments, printing etc.
@dataclass
class SAParams:
    iters: int = 50000
    t0: float = 1.0  # Initial temperature setting
    alpha: float = 0.999  # geometric decay per iteration
    epoch: int = 1  # iterations per temperature step (1 = per-iter decay)


def simulated_annealing(
    text: str,
    layout: Layout,
    params: SAParams,
    rng: random.Random,
) -> Tuple[Layout, float, List[float], List[float], List[float]]:
    """Simulated annealing to minimize path-length cost over character swaps.

    Returns best layout, best cost, and two lists:
    - best cost up to now (monotonically decreasing)
    - cost of current solution (may occasionally go up)
    -trace of deltas (change in cost per iteration)
    These will be used for plotting
    """
   
 
    chars = list(layout.keys())  #getting list of alphabet and space
    current_layout = layout.copy()  # Start with a copy of layout
    best_layout = current_layout.copy()
    
    current_cost = path_length_cost(text, current_layout)    #keep track of cost for current layout.-> may go up or down since SA accepts worse sol too.
    best_cost = current_cost                                 #keeps track of lowest total cost so far.->to start->best cost= qwerty layout cost. 

    best_trace = [best_cost]    #list-> tarcks best_cost after every iteration-> for plotting monotonic best curve.
    current_trace = [current_cost]    #list->tracks current total_cost after every iteration-> for plotting actual search process.
    delta_trace = [0.0]   # no change at first iteration

    T = params.t0  #initialize starting temp for S.A.

    for it in range(params.iters):           #optimization loop for a fixed number of iterations (params.iters).
        # Randomly pick two keys to swap
        a, b = rng.sample(chars, 2)
        
        # Swap positions
        current_layout[a], current_layout[b] = current_layout[b], current_layout[a]

        # Evaluate new cost 
        new_cost = path_length_cost(text, current_layout)
        delta = new_cost - current_cost
        

        # Accept if better or with probability exp(-delta/T)
        if delta < 0 or rng.random() < math.exp(-delta / T):
            current_cost = new_cost
            if new_cost < best_cost:
                best_cost = new_cost  
                best_layout = current_layout.copy()  #accept newlayout->and update the best layout and best cost.
            delta_trace.append(delta)   # accepted move → record actual change
        else:
            # Revert swap-> reject newlayout
            current_layout[a], current_layout[b] = current_layout[b], current_layout[a]
            delta_trace.append(0.0)     # rejected move → no change

        # Geometric temperature decay-> multiplies current temp with alpha after every iteration.-> so that algorithm converges.
        T *= params.alpha

        best_trace.append(best_cost)
        current_trace.append(current_cost)
        

    return best_layout, best_cost, best_trace, current_trace, delta_trace


def plot_costs(
    layout: Layout, best_trace: List[float], current_trace: List[float]
) -> None:

    # Plot cost trace- best cost and current cost
    out_dir = "."
    plt.figure(figsize=(6, 3))
    plt.plot(best_trace, lw=1.5)
    plt.plot(current_trace, lw=1.5)
    plt.xlabel("Iteration")
    plt.ylabel("Best Cost")
    plt.title("Best Cost vs Iteration")
    plt.tight_layout()
    path = os.path.join(out_dir, f"cost_trace.png")
    plt.savefig(path, dpi=150)
    plt.show()
    plt.close()
    print(f"Saved: {path}")

    # Plot layout scatter
    xs, ys, labels = [], [], []
    for ch, (x, y) in layout.items():
        xs.append(x)
        ys.append(y)
        labels.append(ch)

    plt.figure(figsize=(6, 3))
    plt.scatter(xs, ys, s=250, c="#1f77b4")
    for x, y, ch in zip(xs, ys, labels):
        plt.text(
            x,
            y,
            ch,
            ha="center",
            va="center",
            color="white",
            fontsize=9,
            bbox=dict(boxstyle="round,pad=0.15", fc="#1f77b4", ec="none", alpha=0.9),
        )
    plt.gca().invert_yaxis()
    plt.title("Optimized Layout")
    plt.axis("equal")
    plt.tight_layout()
    path = os.path.join(out_dir, f"layout.png")
    plt.savefig(path, dpi=150)
    plt.show()
    plt.close()
    print(f"Saved: {path}")

#to plot loss function
def plot_loss(delta_trace: List[float]) -> None:
    """Plot the loss function (delta cost) over iterations."""

    plt.figure(figsize=(6, 3))
    plt.plot(delta_trace, lw=1, color="red")
    plt.axhline(0, color="black", linestyle="--", lw=1)
    plt.xlabel("Iteration")
    plt.ylabel("Δ Cost")
    plt.title("Loss Function (Delta Cost per Iteration)")
    plt.tight_layout()

    # Save + show
    path = os.path.join(".", "loss_trace.png")
    plt.savefig(path, dpi=150)
    plt.show()
    plt.close()
    print(f"Saved: {path}")



def load_text(filename) -> str:
    if filename is not None:
        with open(filename, "r", encoding="utf-8") as f:
            return f.read()
    # Fallback demo text
    return (
        "the quick brown fox jumps over the lazy dog\n"
        "APL is the best course ever\n"
    )


def main(filename: str | None = None) -> None:
    rng = random.Random(0)
    chars = "abcdefghijklmnopqrstuvwxyz "

    # Initial assignment - QWERTY
    layout0 = initial_layout()

    # Prepare text and evaluate baseline
    raw_text = load_text(filename)
    text = preprocess_text(raw_text, chars)

    #baseline cost
    baseline_cost = path_length_cost(text, layout0)
    print(f"Baseline (QWERTY assignment) cost: {baseline_cost:.4f}")

    # Annealing - give parameter values
    # params = SAParams(iters=, t0=, alpha=)
    # start = time.time()
    # best_layout, best_cost, best_trace, current_trace = simulated_annealing(text, chars_list, layout0, params, rng)
    # dur = time.time() - start
    # print(f"Optimized cost: {best_cost:.4f}  (improvement {(baseline_cost - best_cost):.4f})")
    # print(f"Runtime: {dur:.2f}s over {iters} iterations")
     
     # Annealing parameters
    params = SAParams(iters=50000, t0=1.0, alpha=0.999)

    start = time.time()
    best_layout, best_cost, best_trace, current_trace, delta_trace = simulated_annealing(
        text, layout0, params, rng
    )
    dur = time.time() - start
    print(f"Optimized cost: {best_cost:.4f}  (improvement {baseline_cost - best_cost:.4f})")
    print(f"Runtime: {dur:.2f}s over {params.iters} iterations")

    # Plotting
    plot_costs(best_layout, best_trace, current_trace)
    # New loss plot
    plot_loss(delta_trace)

    #plot_costs(layout0, [], [])


if __name__ == "__main__":
    main()
