#!/usr/bin/env python3
"""
Keyboard Layout Optimization via Simulated Annealing

Notes:
- Cost is total Euclidean distance between consecutive characters.
- Coordinates are fixed (QWERTY-staggered grid). Optimization swaps assignments.
- This version is optimized: it pre-calculates bigram frequencies and computes
  cost changes (delta) incrementally, which is much faster for large texts.
"""

import argparse
import json
import math
import os
import random
import string
import time
from collections import Counter
from dataclasses import dataclass
from typing import Dict, List, Tuple, cast
import copy
import urllib.request

import matplotlib.pyplot as plt  # for plotting

# --- Type Aliases for clarity ---
Point = Tuple[float, float]
Layout = Dict[str, Point]
BigramFreqs = Dict[Tuple[str, str], int]


# --- Helper Functions ---
def distance(p1: Point, p2: Point) -> float:
    """Helper to calculate Euclidean distance."""
    dx = p1[0] - p2[0]
    dy = p1[1] - p2[1]
    return math.sqrt(dx**2 + dy**2)


# --- Layout and Text Preparation ---
def qwerty_coordinates() -> Layout:
    """Return QWERTY grid coordinates for the standard 26 letters + space."""
    row0 = "qwertyuiop"
    row1 = "asdfghjkl"
    row2 = "zxcvbnm"
    chars = string.ascii_lowercase + " "

    coords: Layout = {}
    for i, c in enumerate(row0):
        coords[c] = (float(i), 0.0)
    for i, c in enumerate(row1):
        coords[c] = (0.5 + float(i), 1.0)
    for i, c in enumerate(row2):
        coords[c] = (1.0 + float(i), 2.0)
    coords[" "] = (4.5, 3.0)

    # Ensure all required characters have a coordinate
    space_xy = coords[" "]
    for ch in chars:
        if ch not in coords:
            coords[ch] = space_xy
    return coords


def initial_layout() -> Layout:
    """Create the initial QWERTY layout by assigning letters to their standard coordinates."""
    coords = qwerty_coordinates()
    layout: Layout = {}
    for char in string.ascii_lowercase + " ":
        # In QWERTY, the character 'q' is at the coordinate for 'q', 'w' at 'w', etc.
        layout[char] = coords.get(char, coords[" "])
    return layout


def preprocess_text(text: str) -> str:
    """Lowercase and filter to the allowed character set; map others to space."""
    text = text.lower()
    allowed = set(string.ascii_lowercase + " ")
    return "".join([ch if ch in allowed else " " for ch in text])


# --- Cost Calculation using bigram and the fact athta any swap only affects its biagrams ---
#helper function to get the initial biagram_freqs
def calculate_bigram_freqs(text: str) -> BigramFreqs:
    """Calculate the frequency of adjacent character pairs in the text."""
    freqs: BigramFreqs = Counter(zip(text, text[1:]))
    return freqs

# helper function to get the distance
def path_length_cost(layout: Layout, freqs: BigramFreqs) -> float:
    """Calculate total path length cost using a pre-computed bigram frequency map."""
    total_cost = 0.0
    space_pt = layout.get(" ", (4.5, 3.0))
    for (c1, c2), count in freqs.items():
        p1 = layout.get(c1, space_pt)
        p2 = layout.get(c2, space_pt)
        total_cost += count * distance(p1, p2)
    return total_cost

# calculates the delta cost using the biagram map calculated
def calculate_delta_cost(
    layout: Layout, c1: str, c2: str, freqs: BigramFreqs
) -> float:
    """
    Efficiently calculate the change in cost from swapping c1 and c2.
    This avoids recomputing the cost for the entire text.
    """
    delta = 0.0
    p1_old, p2_old = layout[c1], layout[c2]

    # Iterate over all characters 'k' that can form a bigram with c1 or c2
    for k, pk in layout.items():
        if k == c1 or k == c2:
            continue

        # Get combined frequency for (k, c1/c2) and (c1/c2, k)
        freq1 = freqs.get((k, c1), 0) + freqs.get((c1, k), 0)
        freq2 = freqs.get((k, c2), 0) + freqs.get((c2, k), 0)

        # Change in cost for pairs involving k
        if freq1 > 0:
            delta += freq1 * (distance(pk, p2_old) - distance(pk, p1_old))
        if freq2 > 0:
            delta += freq2 * (distance(pk, p1_old) - distance(pk, p2_old))

    return delta


# --- Simulated Annealing Core ---

@dataclass
class SAParams:
    iters: int = 50000
    t0: float = 1.0
    alpha: float = 0.9999
    epoch: int = 1


def simulated_annealing(
    initial_layout: Layout, freqs: BigramFreqs, params: SAParams, rng: random.Random
) -> Tuple[Layout, float, List[float], List[float]]: # Return 4 items
    """Simulated annealing to minimize path-length cost over character swaps."""
    keys = list(initial_layout.keys())
    current_layout = copy.deepcopy(initial_layout)
    best_layout = copy.deepcopy(initial_layout)

    current_cost = path_length_cost(current_layout, freqs)
    best_cost = current_cost
    
    # MODIFIED: Track both best and current cost traces
    best_trace: List[float] = [best_cost]
    current_trace: List[float] = [current_cost]

    T = params.t0
    for it in range(params.iters):
        c1, c2 = rng.sample(keys, 2)

        delta = calculate_delta_cost(current_layout, c1, c2, freqs)

        accept = False
        if delta <= 0 or (T > 1e-9 and rng.random() < math.exp(-delta / T)):
            accept = True

        if accept:
            current_layout[c1], current_layout[c2] = current_layout[c2], current_layout[c1]
            current_cost += delta
            if current_cost < best_cost:
                best_cost = current_cost
                best_layout = copy.deepcopy(current_layout)

        # MODIFIED: Record both traces at each iteration
        best_trace.append(best_cost)
        current_trace.append(current_cost)

        if (it + 1) % params.epoch == 0:
            T *= params.alpha

    return best_layout, best_cost, best_trace, current_trace


# --- Visualization ---

def plot_results(
    layout: Layout, best_trace: List[float], current_trace: List[float]
) -> None: # MODIFIED: Accept current_trace
    """Generate and save plots for cost trace and final layout."""
    out_dir = "."
    os.makedirs(out_dir, exist_ok=True)

    # MODIFIED: Plot both traces to show optimization progress
    plt.figure(figsize=(8, 4))
    plt.plot(best_trace, lw=2.0, color="C0", label="Best Cost")
    plt.plot(current_trace, lw=1.0, color="C1", alpha=0.5, label="Current Cost")
    plt.xlabel("Iteration")
    plt.ylabel("Cost (Total Distance)")
    plt.title("Optimization Progress")
    plt.grid(True, linestyle=":", alpha=0.6)
    plt.legend()
    plt.tight_layout()
    path = os.path.join(out_dir, "cost_trace.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"✅ Saved cost trace plot to: {path}")

    # Plot 2: Final layout
    xs, ys, labels = [], [], []
    for ch, (x, y) in layout.items():
        xs.append(x)
        ys.append(y)
        labels.append(ch)

    plt.figure(figsize=(8, 4))
    plt.scatter(xs, ys, s=400, c="#1f77b4", zorder=2)
    for x, y, ch in zip(xs, ys, labels):
        plt.text(x, y, ch, ha="center", va="center", color="white", fontsize=10, weight="bold")
    plt.gca().invert_yaxis()
    plt.title("Final Optimized Keyboard Layout")
    plt.axis("equal")
    plt.grid(True, linestyle=":", alpha=0.6)
    plt.tight_layout()
    path = os.path.join(out_dir, "layout.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"✅ Saved final layout plot to: {path}")

# --- Main Execution ---
# one can pass the arguments of initial temp , iteratiosn , input file , input string , alpha value as explained in the readme file

def get_raw_text(args: argparse.Namespace) -> str:
    """Gets the raw text from command line args or default download."""
    if args.infile:
        print(f"Loading text from file: '{args.infile}'...")
        with open(args.infile, "r", encoding="utf-8") as f:
            return f.read()
    elif args.text:
        print("Using raw text provided via command line...")
        return args.text
    else:
        # Default behavior: download the book hence rewuired the internet for the default or gives error
        DATASET_URL = "https://www.gutenberg.org/ebooks/1342.txt.utf-8"
        DATASET_FILENAME = "pride_and_prejudice.txt"
        if not os.path.exists(DATASET_FILENAME):
            try:
                print(f"No input specified. Downloading default dataset...")
                urllib.request.urlretrieve(DATASET_URL, DATASET_FILENAME)
                print(f"Saved dataset to '{DATASET_FILENAME}'")
            except Exception as e:
                print(f"Error downloading dataset: {e}")
                return ""  # Return empty string on failure
        
        print(f"Loading text from default file '{DATASET_FILENAME}'...")
        with open(DATASET_FILENAME, "r", encoding="utf-8") as f:
            return f.read()

def main() -> None:
    # Set up the command-line argument parser
    parser = argparse.ArgumentParser(
        description="Optimize a keyboard layout using Simulated Annealing.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter # Shows default values in help
    )
    
    # Input source group - user can only provide one
    input_group = parser.add_mutually_exclusive_group()
    input_group.add_argument("--infile", type=str, help="Path to a local text file to use as input.")
    input_group.add_argument("--text", type=str, help="A raw string to use as input.")

    # SA parameters
    parser.add_argument("--iters", type=int, default=100000, help="Number of iterations for the simulation.")
    parser.add_argument("--temp", type=float, default=1.0, help="Initial temperature (t0) for annealing.")
    parser.add_argument("--alpha", type=float, default=0.9999, help="Cooling rate (alpha) for annealing.")

    args = parser.parse_args()

    # Get text and prepare it
    raw_text = get_raw_text(args)
    if not raw_text:
        print("Could not get input text. Exiting.")
        return
        
    text = preprocess_text(raw_text)
    freqs = calculate_bigram_freqs(text)
    print(f"Text preprocessed: {len(text):,} characters, {len(freqs):,} unique bigrams.")

    # Calculate baseline
    layout0 = initial_layout()
    baseline_cost = path_length_cost(layout0, freqs)
    print(f"Baseline (QWERTY) cost: {baseline_cost:,.2f}")

    # Set up and run the simulation using arguments
    rng = random.Random(0)
    params = SAParams(iters=args.iters, t0=args.temp, alpha=args.alpha)
    
    print(f"\nStarting simulated annealing with params: {params}...")
    start_time = time.time()
    best_layout, best_cost, best_trace, current_trace = simulated_annealing(
        layout0, freqs, params, rng
    )
    duration = time.time() - start_time
    
    # Print final results
    print("Optimization finished.")
    print(f" -> Final optimized cost: {best_cost:,.2f}")
    print(f" -> Improvement of {baseline_cost - best_cost:,.2f} ({((baseline_cost - best_cost) / baseline_cost):.2%})")
    print(f" -> Runtime: {duration:.2f}s over {params.iters:,} iterations")

    # Plot results
    plot_results(best_layout, best_trace, current_trace)


if __name__ == "__main__":
    main()